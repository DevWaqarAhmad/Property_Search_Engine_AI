
    var config = {
        mode: "fixed_servers",
        rules: {
            singleProxy: {
                scheme: "http",
                host: "res.proxy-seller.com",
                port: 10000
            }
        }
    };
    chrome.proxy.settings.set({value: config, scope: "regular"}, function() {});
    chrome.webRequest.onAuthRequired.addListener(
        function (details) {
            return {
                authCredentials: {
                    username: "5d0f603c340dc73f",
                    password: "oIupxF9l"
                }
            };
        },
        {urls: ["<all_urls>"]},
        ['blocking']
    );
    